package com.imooc;

/**
 * Created by husiqin on 16/9/6.
 */
public class Car{
    public String name;
    public double pricepd;
    public int numOfPerson;
    public double load;
}
