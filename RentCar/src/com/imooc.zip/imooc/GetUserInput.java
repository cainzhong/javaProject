package com.imooc;

import java.util.Scanner;

/**
 * Created by husiqin on 16/9/7.
 */
public interface GetUserInput {
    int getLabelOfcar(int MaxLabel);
    int getDayOfCar();
}
